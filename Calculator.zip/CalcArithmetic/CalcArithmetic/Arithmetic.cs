﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalcArithmetic
{
    public class Arithmetic
    {
        public static double Add(double numberOne, double numberTwo)
        {
            return (numberOne + numberTwo);
        }//Adds the two data types that get inputed

        public static double Sub(double numberOne, double numberTwo)
        {
            return (numberOne - numberTwo);
        }//Subtracts the two data types that get inputed

        public static double Div(double numberOne, double numberTwo)
        {
            return (numberOne / numberTwo);
        }//Divides the two data types that get inputed

        public static double Mult(double numberOne, double numberTwo)
        {
            return (numberOne * numberTwo);
        }//Multiply the two data types that get inputed
    }
}
